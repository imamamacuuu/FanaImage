#include <stdio.h>

int main(){
    for (int i=0; i<9; i++){
        printf("Iterasi ke [ %d ]\n",i);
    }
}
