 #include <stdio.h>
 #include <omp.h>  // Library OpenMP
 int main() {
    #pragma omp parallel
    {
        printf("Hello from SSH Threads [ %d ]\n", omp_get_thread_num());
    }
    return 0;
 }
