 #include <stdio.h>
 #include <omp.h>
 int main() {
    omp_set_num_threads(3);  // set Jumlah thread 3
    #pragma omp parallel
    {
        printf("SSH Thread ke [ %d ] dari [ %d ]\n", omp_get_thread_num(), 
omp_get_num_threads());
    }
    return 0;
 }
