#include <stdio.h>
#include <omp.h>

int main(){
    int total = 0;
    #pragma omp parallel for
    for (int i=0; i<40; i++){
        total+=i;
    }
    printf("Total: [ %d ]\n",total);
    return 0;
}
